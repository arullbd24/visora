$(document).on('change', '#file', function() {
    console.log("File input changed!");

    // Mendapatkan nama file
    var fileName = $(this).val().split('\\').pop();
    console.log("Selected file:", fileName);
    
    // Sembunyikan form upload dan tampilkan tampilan dokumen
    $('.btnSelectDocument').hide();
    $('#documentPreview').removeClass('hidden');
    
    // Menampilkan nama file di tabel
    $('#documentName').text(fileName);
});



// $('#file').change(function() {
//     // Memeriksa apakah event dipicu
//     console.log('File input changed!');
    
//     // Mendapatkan nama file
//     var fileName = $(this).val().split('\\').pop();
//     console.log('Selected file:', fileName);
    
//     // Sembunyikan form upload dan tampilkan tampilan dokumen
//     $('#selectDocument').hide();
//     $('#documentPreview').removeClass('hidden');
    
//     // Menampilkan nama file di tabel
//     $('#documentName').text(fileName);
// });


// $('#file').change(function() {
//     // Mendapatkan nama file
//     var fileName = $(this).val().split('\\').pop();
    
//     // Sembunyikan form upload dan tampilkan tampilan dokumen
//     $('#selectDocument').hide();
//     $('#documentPreview').removeClass('hidden');
    
//     // Menampilkan nama file di tabel
//     $('#documentName').text(fileName);
// });